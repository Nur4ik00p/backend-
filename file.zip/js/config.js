// Configuration
const API_URL = "https://demo.soon-night.lol"
const SOCKET_URL = "https://demo.soon-night.lol"
const FRONTEND_URL = "http://185.189.167.72:3000"

// Storage keys
const TOKEN_KEY = "soon_night_token"
const USER_KEY = "soon_night_user"
const THEME_KEY = "soon_night_theme"
